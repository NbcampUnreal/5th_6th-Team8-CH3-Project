#include "GunBase.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystem.h"
#include "Sound/SoundBase.h"
#include "TimerManager.h"
#include "Engine/World.h"
#include "GameFramework/Controller.h"
#include "GameFramework/DamageType.h"
#include "PlayerCharacter.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Components/DecalComponent.h"

AGunBase::AGunBase()
{
    PrimaryActorTick.bCanEverTick = false;

    GunMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("GunMesh"));
    RootComponent = GunMesh;

    Damage = 20.0f;
    MaxMagazineAmmo = 30;
    CurrentAmmo = MaxMagazineAmmo;
    FireRate = 600.0f;
    WeaponType = EWeaponType::WT_Pistol;

    bIsReloading = false;
    OwningPlayer = nullptr;
}

void AGunBase::BeginPlay()
{
    Super::BeginPlay();
    CurrentAmmo = MaxMagazineAmmo;
    OwningPlayer = Cast<APlayerCharacter>(GetOwner());
}

void AGunBase::SetWeaponHidden(bool bShouldBeHidden)
{
    SetActorHiddenInGame(bShouldBeHidden);
    SetActorEnableCollision(!bShouldBeHidden);
    SetActorTickEnabled(!bShouldBeHidden);
}

void AGunBase::StartFire()
{
    if (bIsReloading) return;

    // [�ذ�å 2: �� źâ �߻�]
    // �߻� ������ �����ϱ� ��, �Ѿ��� �ִ��� ���� ���� Ȯ���մϴ�.
    if (CurrentAmmo <= 0)
    {
        return;
    }
    // ------------------------------------

    if (GetWorld()->GetTimerManager().IsTimerActive(FireTimerHandle)) return;

    // (���� �� �ڵ�� �Ѿ��� 1�� �̻� ���� ���� ����˴ϴ�)
    OnStartFire.Broadcast();

    if (FireRate <= 0.f)
    {
        TraceFire();
    }
    else
    {
        float TimeBetweenShots = 60.0f / FireRate;
        TraceFire();
        GetWorld()->GetTimerManager().SetTimer(FireTimerHandle, this, &AGunBase::TraceFire, TimeBetweenShots, true);
    }
}

void AGunBase::StopFire()
{
    GetWorld()->GetTimerManager().ClearTimer(FireTimerHandle);
    OnStopFire.Broadcast();
}

void AGunBase::Reload()
{
    if (bIsReloading) return;
    if (!OwningPlayer) return;

    // if weapon uses reserve ammo, check
    if (WeaponType != EWeaponType::WT_Pistol && OwningPlayer->GetReserveAmmo(WeaponType) <= 0)
    {
        return;
    }

    // źâ�� ���� �� ������ ���ε� �Ұ���
    if (CurrentAmmo == MaxMagazineAmmo)
    {
        return;
    }

    bIsReloading = true;
    StopFire();
    OnStartReload.Broadcast();

    // 1. ���ε� ���� ���� ���
    if (ReloadSound)
    {
        UGameplayStatics::PlaySoundAtLocation(this, ReloadSound, GetActorLocation());
    }

    float ReloadTime = 3.0f;

    // 2. ���ε� ��Ÿ�� ��� �� ��� �ð����� Ÿ�̸� ����
    if (ReloadMontage && OwningPlayer && OwningPlayer->GetFPMesh() && OwningPlayer->GetFPMesh()->GetAnimInstance())
    {
        // 1��Ī �޽��� �ִϸ��̼� �ν��Ͻ��� ������ ��Ÿ�ָ� ���
        UAnimInstance* FPAnimInstance = OwningPlayer->GetFPMesh()->GetAnimInstance();
        FPAnimInstance->Montage_Play(ReloadMontage, 1.0f);

        // ��Ÿ���� ���̷� ReloadTime�� �����Ͽ� �ִϸ��̼ǰ� Ÿ�̸Ӹ� ����ȭ
        ReloadTime = ReloadMontage->GetPlayLength();
    }

    // << [���� 4] OwningPlayer->GetFPMesh() ȣ���� ���� FP_Mesh�� �����մϴ�.
    if (ReloadMontage && OwningPlayer && OwningPlayer->GetFPMesh() && OwningPlayer->GetFPMesh()->GetAnimInstance())
    {
        // 1��Ī �޽��� �ִϸ��̼� �ν��Ͻ��� �����ɴϴ�.
        UAnimInstance* FPAnimInstance = OwningPlayer->GetFPMesh()->GetAnimInstance();

        // ��Ÿ�ָ� ����ϰ�, �� ��� �ð����� ReloadTime�� �����մϴ�.
        FPAnimInstance->Montage_Play(ReloadMontage, 1.0f); // 1.0f�� ��� �ӵ�
        ReloadTime = ReloadMontage->GetPlayLength();
    }

    GetWorld()->GetTimerManager().SetTimer(ReloadTimerHandle, this, &AGunBase::FinishReload, ReloadTime, false);
}

void AGunBase::FinishReload()
{
    if (!OwningPlayer)
    {
        bIsReloading = false;
        OnFinishReload.Broadcast();
        return;
    }

    int32 AmmoToReload = MaxMagazineAmmo - CurrentAmmo;
    if (AmmoToReload <= 0)
    {
        bIsReloading = false;
        OnFinishReload.Broadcast();
        return;
    }

    int32 AmmoConsumed = 0;

    // ������ ����ź ���� ���� �׻� ���� ����
    if (WeaponType == EWeaponType::WT_Pistol)
    {
        AmmoConsumed = AmmoToReload;
    }
    else
    {
        AmmoConsumed = OwningPlayer->ConsumeAmmoForReload(WeaponType, AmmoToReload);
    }

    CurrentAmmo += AmmoConsumed;
    bIsReloading = false;

    GetWorld()->GetTimerManager().ClearTimer(ReloadTimerHandle);
    OnFinishReload.Broadcast();
}

void AGunBase::TraceFire()
{
    if (CurrentAmmo <= 0 || bIsReloading)
    {
        StopFire();
        return;
    }

    CurrentAmmo--;


    if (!OwningPlayer)
    {
        OwningPlayer = Cast<APlayerCharacter>(GetOwner());
    }
    if (!OwningPlayer) return;

    AController* OwnerController = OwningPlayer->GetController();
    if (!OwnerController) return;

    // Effects
    if (MuzzleFlash && GunMesh)
    {
        UGameplayStatics::SpawnEmitterAttached(MuzzleFlash, GunMesh, FName("Muzzle"));
    }
    if (FireSound)
    {
        UGameplayStatics::PlaySoundAtLocation(this, FireSound, GetActorLocation());
    }

    if (FireMontage && OwningPlayer->GetFPMesh() && OwningPlayer->GetFPMesh()->GetAnimInstance())
    {
        UAnimInstance* FPAnimInstance = OwningPlayer->GetFPMesh()->GetAnimInstance();
        FPAnimInstance->Montage_Play(FireMontage, 1.0f);
    }

    FVector StartLocation;
    FRotator CameraRotation;
    OwnerController->GetPlayerViewPoint(StartLocation, CameraRotation);
    FVector TraceEnd = StartLocation + (CameraRotation.Vector() * 10000.f);

    FHitResult Hit;
    FCollisionQueryParams QueryParams;
    QueryParams.AddIgnoredActor(this);
    QueryParams.AddIgnoredActor(GetOwner());

    if (GetWorld()->LineTraceSingleByChannel(Hit, StartLocation, TraceEnd, ECC_Visibility, QueryParams))
    {
        UGameplayStatics::ApplyPointDamage(
            Hit.GetActor(),
            Damage,
            CameraRotation.Vector(),
            Hit,
            OwnerController,
            this,
            UDamageType::StaticClass()
        );

        if (ImpactFX)
        {
            UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ImpactFX, Hit.ImpactPoint, Hit.ImpactNormal.Rotation());
        }

        if (ImpactDecal && Hit.GetComponent())
        {
            UDecalComponent* DecalComp = UGameplayStatics::SpawnDecalAttached(
                ImpactDecal,
                FVector(ImpactDecalSize),
                Hit.GetComponent(),
                Hit.BoneName,
                Hit.ImpactPoint,
                Hit.ImpactNormal.Rotation(),
                EAttachLocation::KeepWorldPosition,
                ImpactDecalLifeSpan
            );

            if (DecalComp)
            {
                DecalComp->SetWorldLocation(Hit.ImpactPoint + Hit.ImpactNormal * 0.5f);
            }
        }

        if (ImpactSound)
        {
            UGameplayStatics::PlaySoundAtLocation(GetWorld(), ImpactSound, Hit.ImpactPoint);
        }

        if (UPrimitiveComponent* HitComp = Hit.GetComponent())
        {
            if (HitComp->IsSimulatingPhysics())
            {
                HitComp->AddImpulseAtLocation(CameraRotation.Vector() * 50000.0f, Hit.ImpactPoint);
            }
        }
    }
}