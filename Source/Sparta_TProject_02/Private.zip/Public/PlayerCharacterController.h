#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PlayerCharacterController.generated.h"

class UInputMappingContext;

UCLASS()
class SPARTA_TPROJECT_02_API APlayerCharacterController : public APlayerController
{
	GENERATED_BODY()

public:
	APlayerCharacterController();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Input")
	UInputMappingContext* InputMappingContext;

	//GameMode ȣ��
	void TriggerStageReward();
	void OnGameOver();
	void OnGameWin();

	UFUNCTION(Exec)
	void ToggleUIInput();

protected:
	virtual void BeginPlay() override;
	bool bIsInUIOnlyMode;
};