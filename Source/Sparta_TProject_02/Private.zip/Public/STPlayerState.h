#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "STPlayerState.generated.h"

//ü�� ���� �˶�: ����ü��, �ִ�ü��
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnHealthChangedSignature, float, CurrentHealth, float, MaxHealth);
//ź�� ���� �˶�: ����ź��, �ִ�ź��
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnAmmoChangedSignature, int32, CurrentAmmo, int32, MaxAmmo);
//ų �� ����: �� ų ��
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnKillCountChangedSignature, int32, NewKillCount);

UCLASS()
class SPARTA_TPROJECT_02_API ASTPlayerState : public APlayerState
{
	GENERATED_BODY()

public:
	ASTPlayerState();

	//-------UI���ε� ��������Ʈ---------
	UPROPERTY(BlueprintAssignable, Category="PlayerState | Events")
	FOnHealthChangedSignature OnHealthChanged;

	UPROPERTY(BlueprintAssignable, Category = "PlayerState | Events")
	FOnAmmoChangedSignature OnAmmoChanged;

	UPROPERTY(BlueprintAssignable, Category = "PlayerState | Events")
	FOnKillCountChangedSignature OnKillCountChanged;

	//---�� ������ ���� �Լ� (ĳ����/ ������ ȣ���)

	//ü��
	UFUNCTION(BlueprintCallable, Category = "PlayerState | Health")
	void SetHealth(float NewHealth);

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Health")
	void AddHealth(float HealthDelta);

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Health")
	void SetMaxHealth(float NewMaxHealth);

	//ź��
	UFUNCTION(BlueprintCallable, Category = "PlayerState | Ammo")
	void SetCurrentAmmo(int32 NewAmmo);

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Ammo")
	void AddAmmo(int32 AmmoDelta);

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Ammo")
	void SetMaxAmmo(int32 NewMaxAmmo);

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Ammo")
	bool UseAmmo(int32 AmmoToUse = 1);

	//ų ��
	UFUNCTION(BlueprintCallable, Category = "PlayerState | Combat")
	void AddKill();

	UFUNCTION(BlueprintCallable, Category = "PlayerState | Combat")
	void ResetKills(const FString& NewName);

	//Getters

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	float GetCurrentHealth() const { return CurrentHealth; }

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	float GetMaxHealth() const { return MaxHealth; }

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	int32 GetCurrentAmmo() const { return CurrentAmmo; }

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	int32 GetMaxAmmo() const { return MaxAmmo; }

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	int32 GetKillCount() const { return KillCount; }

	FString GetPlayerName() const;

	UFUNCTION(BlueprintCallable, Category = "PlayerState")
	void SetPlayerName(const FString& NewName);

protected:
	virtual void BeginPlay() override;

	//---������ ����
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayerState | Identity")
	FString PlayerName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayerState | Config")
	float MaxHealth;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "PlayerState | Config")
	float CurrentHealth;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "PlayerState | Config")
	int32 MaxAmmo;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "PlayerState | Config")
	int32 CurrentAmmo;

	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "PlayerState | Config")
	int32 KillCount;

};
