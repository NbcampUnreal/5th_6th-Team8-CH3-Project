#include "Gem.h"

UGem::UGem()
{
	ItemType = "Gem";
}