#include "Weapon.h"

UWeapon::UWeapon()
{
	Damage = 0;
	ItemType = "Weapon";
}
