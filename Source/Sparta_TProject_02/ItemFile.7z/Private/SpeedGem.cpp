#include "SpeedGem.h"

USpeedGem::USpeedGem()
{
	SpeedValue = 1;
}

float USpeedGem::GetSpeedValue()
{
	return SpeedValue;
}