#include "AttackGem.h"

UAttackGem::UAttackGem()
{
	AttackValue = 1;
}

int32 UAttackGem::GetAttackValue()
{
	return AttackValue;
}