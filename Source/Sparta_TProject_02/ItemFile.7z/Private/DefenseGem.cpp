#include "DefenseGem.h"

UDefenseGem::UDefenseGem()
{
	DefenseValue = 1;
}

int32 UDefenseGem::GetDefenseValue()
{
	return DefenseValue;
}