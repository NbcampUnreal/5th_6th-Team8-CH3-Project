#include "BasicPistol.h"

UBasicPistol::UBasicPistol()
{
	ItemName = "BasicPistol";
	Damage = 10;
}
