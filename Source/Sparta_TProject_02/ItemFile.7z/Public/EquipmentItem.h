#pragma once
#include "CoreMinimal.h"
#include "Item.h"
#include "EquipmentItem.generated.h"

UCLASS()
class UEquipmentItem : public UItem
{
	GENERATED_BODY()
	
};
