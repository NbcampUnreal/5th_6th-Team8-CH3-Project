#pragma once
#include "CoreMinimal.h"
#include "EquipmentItem.h"
#include "Gem.generated.h"

UCLASS()
class UGem : public UEquipmentItem
{
	GENERATED_BODY()
	
public:
	UGem();
};
