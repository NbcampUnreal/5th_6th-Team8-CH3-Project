#pragma once
#include "CoreMinimal.h"
#include "MaterialItem.h"
#include "GemDust.generated.h"

UCLASS()
class SPARTA_TPROJECT_02_API UGemDust : public UMaterialItem
{
	GENERATED_BODY()
	
public:
	UGemDust();
};
