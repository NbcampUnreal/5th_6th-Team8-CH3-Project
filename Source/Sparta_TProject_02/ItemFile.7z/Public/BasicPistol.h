#pragma once
#include "CoreMinimal.h"
#include "Weapon.h"
#include "BasicPistol.generated.h"

UCLASS()
class UBasicPistol : public UWeapon
{
	GENERATED_BODY()
	
public:
	UBasicPistol();
};
